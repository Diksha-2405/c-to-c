Use Courses

select*from students
 
 --count of institutename .1

 select InstituteName , count(StudentId) as NumberOfStudents
 From Institute inner join Students on Students.InstituteId= Institute.InstituteId
 group by Institutename

 select InstituteName, Count(*) as StudentId
 from Institute 
 Inner join students on Institute.InstituteId = Students.InstituteId
 group by InstituteName

 --function.2
 create function gettotalstudentininstitute (InstituteId INT)
 return INT
 begin
    declare totalStudents int

end

 --view.3
 create view sm_getStudentName as
 select Students.StudentName,Course.CourseName,DurationInWeeks from Students inner join Course on
 Students.InstituteId= Course.InstituteId

 select * from  sm_getStudentName

 --transaction--4

 Begin Transaction
  Insert into Students select '11', 'Hanna','12'
  print 'Newly created StudentId = '+CAST(@@Identity as NVARCHAR)
  DELETE from Students where StudentId =5
  update Students set StudentName='Ritu' where InstituteId=4
COMMIT
select*from Students

--procedures .5
create procedure vm_getCourseDetails as
select CourseName, StudentId, CourseId, DurationInWeeks from Course
Inner join Students on Students.InstituteId=Course.InstituteId

select* from vm_getCourseDetails

exec vm_getCourseDetails