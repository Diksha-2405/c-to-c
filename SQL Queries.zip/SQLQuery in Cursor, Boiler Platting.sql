--cursor template

--step 1
declare c1 cursor for <select-query>

--step2
open c1
--step 3
fetch next from c1
into <variables-corresponding-to-columns-in-select-query>

--step 4
--your logic
--use conditions,loops,queries etc

--step 5
close c1

--step 6
DEAllocate c1
USE TaskManagement
select * from EMployee

Declare @EmpId Int,@EmpName NVARCHar(50),@ManagerId Int, @Doj AS DATETIME
Declare c1 cursor for
select EmpId, EmpName, ManagerId, Doj from Employee
Where IsActive=1

OPEN c1
fetch next from c1
into @EmpId, @EmpName, @ManagerId, @DOj
print 'IN cursor'
WHile @@FETCH_STATUS = 0
BEGIN
IF @DOJ >'01-01-2023' AND @DOJ < '12-28-2023'
 print 'INcrement for '+@EmpName + ': 10%'
ELSE IF @Doj BETWEEN '01-01-2023' and '12-12-2023'
 PRINT 'INCREMENT FOR ' +@EmpName + ':20%'
ELSE IF @Doj BETWEEN '01-01-2023' AND '12-31-2023'
 PRINT @EmpName + ' IS not eligible for increments yet'
ELSE IF @Doj <'01-01-2023'
print 'Increment for ' +@EmpName + ':30%'
FETCH NEXT FROM c1 INTO @EmpID, @EmpName, @ManagerID, @Doj
END
close c1
DEALLOCATE c1