USE TaskManagement
select* from Employee

--select without form
select 'Without using from clause' as [Message],
 '1001' as [Code Number],
 'Ha ha ha' as Comments

 --select using variable
 DECLARE @varName Nvarchar(50),
 @var3 Int 
 SET @varName ='A new value'

 SELECT @varName as [using Variable]

 -- Use select to assign a value to a variable
 DECLARE @var2 INT
 SET @var2 = 1001
 SELECT @var2 as [empid]

 --select top few records
 select top 2 EmpId,EmpName from Employee

 -- select with order by asc
 SELECT * from Employee ORDER By EmpName DESC

 SELECT TOP 1*  FROM Employee ORDER BY EmpId DESC

 SELECT DISTINCT EmpName from Employee

 --select with where caluse

 select *from Employee WHERE EmpName='garima' AND EmpId=1001
 select* from Employee WHERE EmpName='garima' OR EmpId =10011
 select TOP 2 * from Employee
 WHERE EmpName <> 'garima'
 select * from Employee WHERE EmpName IN('Diksha', 'garima', 'Meena')
 select * from Employee WHERE EmpName NOT IN('Manoj', 'garima', 'Meena')
 select* from Employee where EmpId Between 1002 AND 2002

 --get all employees who joined in a particular month eg: 1-10-2023 to 31-10-2023
 --get all the names that start with M
 -- * Use Wildcards: *: One or more,-: only one character, %: one or more

 SELECT * from Employee WHERE EmpName LIKE 'M%'
 -- all names end with a
 SELECT * from Employee WHERE EmpName LIKE '%A'

 --get all name that have one space
 SELECT * from Employee WHERE EmpName LIKE '% %'

 --all names that have 2nd character as 'a'
 SELECT * from Employee WHERE EmpName LIKE '_a%'

 --Nested select staements in place of columns
 SELECT(SELECT EmpName from Employee where EmpId =1001) as [Employee Name],
 (SELECT 5+5) as [percent Hike]

 --select statements to assign a value for a variable
 DECLARE @EmpId INT
 SET @EmpId= (SELECT TOP 1 EmpId FROM Employee Where EmpName= 'garima')
 SELECT @EmpId as [EmpId Assigned To Variable]

 --select statements to assign &print value of a variable

 DECLARE @newValue INT
 SELECT @newValue= (SELECT TOP 1 EmpId from Employee Where EmpName='garima')
 SELECT @newValue


 --print as log message: see messages tab of result window. Used CAST() to cast a value to a different datatypes
 PRINT 'The final value of the variable @newValue = '+ CAST(@newValue AS nVarchar)

 --get EmpNmaes displayed as EmpNmae-EmpId. ex: Meena-2001
 select EmpName + '-' + CAST(EmpId as nVarchar) as FormattedName from Employee

 select*from Task
 where name='coding'

select*from Task where EndDate BETWEEN '2023-10-20' and '2023-10-30'
 
 select* from Task where startDate= '2023-10-25'

 select name + '-' + 'starts on' + CAST(StartDate as nVarchar) + 'ends on' + CAST(EndDate as nVarchar) from Task

 select name ='Coding' from Task where StartDate='2023-10-24' 

 --create a quick Backup table
 select *into Employeebackup
 from Employee
 where ManagerId IS NOT NULL

 --lone a table - Only Its schema
 select*into EmployeeClone
 from Employee
 where 0=1