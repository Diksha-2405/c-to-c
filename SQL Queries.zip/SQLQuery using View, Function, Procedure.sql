--using sele,ct with more than one tables

--display EMpNmaes with TaskIds
select E.EmpName, ET.taskId from Employee as E, Employeetask as ET
WHERE E.EmpId = ET.EmpId

--display Task Names with EmpIds

select T.Name, E.EmpId from Employee as E, Task as T,Employeetask as ET
WHERE E.EmpId = ET.EmpId

--get EmpNames with their corresponding task ids

select E.EmpName,ET.TaskId from Employee as E INNER JOIN EmployeeTask as ET 
  on E.EmpId=ET.EmpId

--get task names with their matching EmpIds
select t.[name],ET.EmpId from task as T INNER JOIN Employeetask as ET
  on t.taskId= Et.taskId

--get EmpNames with their corresponding Tasknames
select E.EmpName as[Employee Name],T.[Name] as [Working on task]
From Employee as E INNER JOIN Employeetask as ET
on E.EmpId =ET.EmpId
INNER JOIN Task as T
on T.TaskId=ET.TaskId

--create a clone EMp task table

select *INTO EmpTaskBackup
from Employeetask

--taskids for all EmpNames

select E.[Empname], ET.TaskId from Employee as E LEFT OUTER JOIN Employeetask as ET
  ON E.EmpId = ET.EmpId

  select E.[EmpName], ET.TaskId from EmployeeTask as ET RIGHT OUTER JOIN Employee as E
    ON ET.EmpId =E.EmpId


	select E.EmpName, ET.TaskId from EMployee as E full Outer JOIN EmpTaskBackup as ET
	ON E.EmpId= ET.EmpId

	select *from Employee as E CROSS JOIN Task as T

	--view
create view vw_EmployeetaskNames AS
select E.EmpName, T.[Name] from employee as E LEFT OUTER JOIN Employeetask as ET on E.EmpId = ET.EmpId
	LEFT OUTER JOIN Task as T On T.TaskId= ET.TaskId
select  *  from vw_EmployeetaskNames

create procedure sp_GetEmployeetaskNames as
select E.EmpName, T.[name] from Employee as E LEFT OUTER JOIN Employeetask as ET on E.EmpId = ET.EmpId
  LEFT OUTER JOIN Task as T on T.TaskId = ET.TaskId
  exec sp_GetEmployeetaskNames


  --procedure
  ALTER  PROCEDURE sp_GetTaskNameForEmployee (@EmpName NVARCHAR(50))
  AS
 SELECT E.EmpName, T.[name] FRom Employee as E LEFT OUTER JOIN Employeetask as ET ON E.EmpId= ET.EmpId
 LEFT OUTER JOIN Task as T On T.TaskId=ET.TaskId
 WHere E.EmpName = @EmpName AND T.[name] IS NOT NULL
 exec sp_GetTaskNameForEmployee 'Manoj'



--function
 create function fn_GetTaskNameForEmployee (@EmpName NVARCHAR(50))
 RETURNS NVARCHAR(50)
 AS
 BEGIN
      RETURN (SELECT TOP 1 t.[name] FROM Employee as E LEFT OUTER JOIN EmployeeTask as ET on E.EmpId = ET.EmpId
	                      LEFT OUTER JOIN Task as T ON T.TaskId = ET. TaskId
      WHERE E.EmpName = @EmpName AND T.[name] IS NOT NULL)

 END

 SELECT [dbo].[fn_GetTaskNameForEmployee]('MAnoj')


--GROUP BY CLAUSE
 SELECT E.EmpName, COUNT(T.[Name]) as TaskCount from Employee as E LEFT OUTER JOIN Employeetask as ET on E.EmpId= ET.EmpId
                                   LEFT OUTER JOIN Task as T on T.TaskId = ET.TaskId
      GROUP BY E.EmpName

--RULES for GROUP bY
--MUST have aggregation function in select
--Must have atleast one other column that does not use aggregation function
--Eg: COUNT(T.[Name]) : Column that used aggreagation function
-- E.EmpName: One other column without aggregation function

SELECT E.EmpName, COUNT(T.[Name]) as TaskCount from Employee as E LEFT OUTER JOIN Employeetask as ET on E.EmpId= ET.EmpId
                                   LEFT OUTER JOIN Task as T on T.TaskId = ET.TaskId
      GROUP BY E.EmpName
      Having Count(T.[Name]) =0



